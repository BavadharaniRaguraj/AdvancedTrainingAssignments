import java.util.regex.Pattern;

public class javaissimple {
	
	
	
    static String reverseWords(String str)
    {
  
        // Specifying the pattern to be searched
        Pattern pattern = Pattern.compile("\\s");
  
        // splitting String str with a pattern
        // (i.e )splitting the string whenever their
        //  is whitespace and store in temp array.
        String[] temp = pattern.split(str);
        String result = "";
  
        // Iterate over the temp array and store
        // the string in reverse order.
        for (int i = 0; i < temp.length; i++) {
            if (i == temp.length - 1)
                result = temp[i] + result;
            else
                result = " " + temp[i] + result;
        }
        return result;
    }
  
	
	
	
	public static String reverseWord(String str){  
	    String words[]=str.split("\\s");  
	    String reverseWord="";  
	    for(String w:words){  
	        StringBuilder sb=new StringBuilder(w);  
	        sb.reverse();  
	        reverseWord+=sb.toString()+" ";  
	    }  
	    return reverseWord.trim();  
	}  
	
	
	
	static String firstLetterWord(String str)
    {
        String result = "";

        boolean v = true;
        for (int i = 0; i < str.length(); i++)
        {
            if (str.charAt(i) == ' ')
            {
                v = true;
            }
            
            else if (str.charAt(i) != ' ' && v == true)
            {
                result += (str.charAt(i));
                v = false;
            }
        }
 
        return result;
    }
	
	
	
	
	public static void main(String[] args) {
		
		
		String str = "JAVA is Simple";
		
		System.out.println(str.toUpperCase());
		System.out.println(str.toLowerCase());
		
		
		
		 
		 System.out.println(firstLetterWord(str));
		
		
		String s1 = "JAVA is Simple";
        System.out.println(reverseWords(s1));
  
		
		
		
		System.out.println(javaissimple.reverseWord("JAVA is Simple"));
		
		String str1 = "JAVA is Simple";
		int count = 0;  
        
         
        for(int i = 0; i < str1.length(); i++) {  
            if(str1.charAt(i) != ' ')  
                count++;  
        }  
        
		 System.out.println("Total length is: "+count);
		
		
	}

}
