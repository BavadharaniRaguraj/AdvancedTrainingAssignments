package book;

public class Book {

    private String bookName;
	    private float bookPrice;
	    
	    
	    public void setBookName(String bookName)
	    {
	        this.bookName=bookName;
	    }
	    
	    public String getBookName()
	    {
	        return this.bookName;
	    }
	    
	    public void setBookPrice(float bookPrice)
	    {
	        this.bookPrice=bookPrice;
	    }
	    
	    public float getBookPrice()
	    {
	        return this.bookPrice;
	    }
	  

}
