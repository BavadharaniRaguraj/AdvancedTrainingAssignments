public class CheckPalindrome {

	  public static void main(String[] args) {

 
		  String msg ="malayalam";
          msg = msg.replaceAll("[^A-Za-z]", "").toUpperCase();
          String rev = new StringBuilder(msg).reverse().toString();
          if(msg.equals(rev)) {
              System.out.println("Given String "+msg+" is a Palindrome.");
          }
          else
          {
              System.out.println("Given String "+msg+" is not a Palindrome.");
          }
      } 
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  /* if (isPalindrome(args))

    System.out.println(args + " is a palindrome");

  else
    System.out.println(args + " is not a palindrome");

}

/** Check if a string is a palindrome */

/*public static boolean isPalindrome(String[] args) {

	// The index of the first character in the string

  int low = 0;

  int high = args.length - 1;

  while (low < high) {

    if (low != high)

      return false; // Not a palindrome

    low++;

    high--;

  }

  return true; // The string is a palindrome

}*/

}


