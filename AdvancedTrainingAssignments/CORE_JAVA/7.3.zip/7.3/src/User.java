
	import java.io.Serializable;

	public class User implements Serializable {
		 
		  private static final long serialVersionUID = 7829136421241571165L;
		  
		  private String pid;
		  private String pname;
		 
		  
		  public User(String pid, String pname) {
		    super();
		    this.pid = pid;
		    this.pname = pname;
		    
		  }
		   
		  public User() {
		    super();
		  }
		  
		public String getPid() {
			return pid;
		}

		public String getPname() {
			return pname;
		}
	
		
		
		public void setPid(String apid) {
			pid = apid;
		}

		
		public void setPname(String apname) {
			pname = apname;
		}

		
		
		  
		}

