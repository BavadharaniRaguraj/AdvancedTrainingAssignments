import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Product {
	
	public static void main(String[] args) 
	  {
	    
	    User p1 = new User("P001","Maruti 800");
	    
	    try
	    {
	      FileOutputStream fileOut = new FileOutputStream("User.ser");
	      ObjectOutputStream out = new ObjectOutputStream(fileOut);
	      out.writeObject(p1);
	      
	      out.close();
	      fileOut.close();
	    } 
	    catch (IOException i) 
	    {
	      i.printStackTrace();
	    }
	 
	    
	    User deserializedUser = null;
	    try
	    {
	      FileInputStream fileIn = new FileInputStream("User.ser");
	      ObjectInputStream in = new ObjectInputStream(fileIn);
	      deserializedUser = (User) in.readObject();
	      in.close();
	      fileIn.close();
	 
	      
	      System.out.println("Product ID : "+deserializedUser.getPid());
	      System.out.println("Product Name : "+deserializedUser.getPname());
	      
	    } 
	    catch (IOException ioe) 
	    {
	      ioe.printStackTrace();
	    } 
	    catch (ClassNotFoundException cnfe) 
	    {
	      cnfe.printStackTrace();
	    }
	  }


}
