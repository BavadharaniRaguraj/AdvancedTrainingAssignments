package hashset;


import java.util.ArrayList;
import java.util.HashSet;

public class Product {
	
		public static void main(String[] args)
	    {
			
	        HashSet<String> pid = new HashSet<String>();
	 
	        HashSet<String> pname = new HashSet<String>();
	   	 
	        
	        pid.add("P001");
	        pname.add("Maruti 800");
	        pid.add("P002");
	        pname.add("Maruti Zen");
	        pid.add("P003");
	        pname.add("Maruti Dezire");
	        pid.add("P004");
	        pname.add("Maruti Alto");
	        pid.add("P005");
	        pname.add("Ford Raptor");
	        pid.add("P006");
	        pname.add("Jeep Gladiator");
	        pid.add("P007");
	        pname.add("Lamborghini Diablo");
	        pid.add("P008");
	        pname.add("Ferrari Testarossa");
	        pid.add("P009");
	        pname.add("Lamborghini Huracan");
	        pid.add("P010");
	        pname.add("Jensen Interceptor");
	        
	       
	        
	        System.out.println(pid);
	        System.out.println(pname);
	        
	        System.out.println("List contains Ford Raptor or not:" + pname.contains("Ford Raptor"));
	 
	        
	        pname.remove("Lamborghini Huracan");
	        System.out.println("List after removing Lamborghini Huracan:" + pname);
	    }
	 
}
