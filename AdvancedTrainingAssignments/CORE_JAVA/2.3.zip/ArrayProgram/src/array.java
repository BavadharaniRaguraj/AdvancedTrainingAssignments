import java.util.Arrays;

public class array {
	
	
	public static void main(String[] args) {
		
		int n=18;
		
	    int A[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
		int sum = 0; // initialize sum
        int i;
      
        for (i = 0; i < A.length; i++)
           sum +=  A[i];
      System.out.println("SUM :"+sum);
   
        System.out.println("\nInitial Array:\n" + Arrays.toString(A));
   
        A[15] = sum;
        
        System.out.println("\nSumOfArray\n "+ Arrays.toString(A));
        
        A[16] = sum/2;
        
        System.out.println("\nAverageArray\n "+ Arrays.toString(A));

        int min = A[0];
	       int index=0;

	       for(int k = 0; k < A.length-1; k++)
	       {
	            if(min > A[k])
	            {
	                min = A[k];
	                index=k;
	            }
	        }

	        System.out.println("\nIndex position of Smallest value in a given array is  :  "+index);
	
	A[17]=A[13];
 
     
        System.out.println("\nSmallestArray\n "+ Arrays.toString(A));

		
	}
        
        
        
        
}
