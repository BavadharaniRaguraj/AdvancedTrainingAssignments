package arraylist;

import java.util.*;  
class JavaExample{  
   public static void main(String args[]){  
      ArrayList<String> alist=new ArrayList<String>();  
      alist.add("Steve");
      alist.add("Tim");
      alist.add("Lucy");
      alist.add("Pat");
      alist.add("Angela");
      alist.add("Tom");
  
      //displaying elements
      System.out.println(alist);
      
      if(alist.contains("Lucy"))
          System.out.println("Lucy is available in the ArrayList");
       else
          System.out.println("Lucy is not available in the ArrayList");
    
   
      if(alist.contains("Jack"))
          System.out.println("Jack is available in the ArrayList");
       else
          System.out.println("Jack is not available in the ArrayList");
    
   
   }
  
     
     
}