package expressionparsers;

import java.util.StringTokenizer;

public class CountTokens {

	public static void main(String[] args) 
	{
		//create StringTokenizer object
		String S="23  +      45   - (   343   /   12  )";
		
		StringTokenizer st = new StringTokenizer(S, " ");

		// search for token while the string ends.
		while(st.hasMoreTokens())
		{
			// print all the tokens.
			
			System.out.println(st.nextToken());
		}
	}
	
	
}

