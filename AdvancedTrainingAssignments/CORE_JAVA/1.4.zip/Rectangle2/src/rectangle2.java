
public class rectangle2 {

	float length;  
	 float width;  
	 float len;
	 float wid;
	 
	 void area(float l,float w){ 
		 
		 length=l;
		 width=w;
		 
		 
	  if (((l>0) && (l<20)) &&  ((w>0) && (wid<20) ))
	  {
		  len=l;
	      wid=w;
	  }
	  else
	  {
		  len=0;
		  wid=0;
	  }

	  
	 }  
	 void calculateArea(){
		 
		 System.out.println("Length = "+len);
		 System.out.println("Width = "+wid);
		 
		 System.out.println("Area = "+(len*wid));
		 
		 float perimeter = (2 * (len + wid));
			System.out.println("Perimeter: " + perimeter);
			
		 System.out.println("\n");
		 }  
	}  
	class TestRectangle{  
	 public static void main(String args[]){  
	  rectangle2 r1=new rectangle2(),r2=new rectangle2(),r3=new rectangle2(),r4=new rectangle2(),r5=new rectangle2();  
	  r1.area(11,1);  
	  r2.area(3,15); 
	  r3.area(23, 6);
	  r4.area(10, 3);
	  r5.area(82, 70);
	  r1.calculateArea();  
	  r2.calculateArea(); 
	  r3.calculateArea(); 
	  r4.calculateArea(); 
	  r5.calculateArea(); 
	}  

	
}	

