
public class Rectangle {
	
	 int length;  
	 int width;  
	 
	 void area(int l,int w){ 
		 
	  length=l;
	  width=w;
	  
	 }  
	 void calculateArea(){
		 
		 System.out.println("Length = "+length);
		 System.out.println("Width = "+width);
		 
		 System.out.println("Area = "+(length*width));
		 System.out.println("\n");
		 }  
	}  
	class TestRectangle{  
	 public static void main(String args[]){  
	  Rectangle r1=new Rectangle(),r2=new Rectangle(),r3=new Rectangle(),r4=new Rectangle(),r5=new Rectangle();  
	  r1.area(11,5);  
	  r2.area(3,15); 
	  r3.area(23, 6);
	  r4.area(10, 3);
	  r5.area(82, 70);
	  r1.calculateArea();  
	  r2.calculateArea(); 
	  r3.calculateArea(); 
	  r4.calculateArea(); 
	  r5.calculateArea(); 
	}  

}
