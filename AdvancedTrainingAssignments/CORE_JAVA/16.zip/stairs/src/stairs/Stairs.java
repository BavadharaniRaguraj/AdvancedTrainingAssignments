package stairs;

public class Stairs {
	
	static int fib(int k)
    {
        if (k <= 1)
            return k;
        return fib(k - 1) + fib(k - 2);
    }
 
    
    static int countWays(int n)
    {
        return fib(n + 1);
    }
 
    
    public static void main(String args[])
    {
        int n = 3;
        System.out.println(countWays(n));
    }

}
