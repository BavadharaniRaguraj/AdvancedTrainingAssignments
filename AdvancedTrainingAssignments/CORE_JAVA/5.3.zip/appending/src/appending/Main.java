package appending;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {

	public static void main(String[] args) {
		
		String input = "sample # text * with & special@ characters";
	      String regex = "[^a-zA-Z0-9\\s+]";
	      String specialChars = "";
	      System.out.println("Input string: \n"+input);
	      //Creating a pattern object
	      Pattern pattern = Pattern.compile(regex);
	      //Matching the compiled pattern in the String
	      Matcher matcher = pattern.matcher(input);
	      //Creating an empty string buffer
	      StringBuffer sb = new StringBuffer();
	      while (matcher.find()) {
	         specialChars = specialChars+matcher.group();
	         matcher.appendReplacement(sb, "");
	      }
	      matcher.appendTail(sb);
	      System.out.println("Result: \n"+ sb.toString()+specialChars );
	   }
	
	
	
}
