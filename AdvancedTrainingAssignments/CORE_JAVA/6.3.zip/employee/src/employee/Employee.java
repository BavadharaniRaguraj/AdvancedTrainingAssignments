package employee;

import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class Employee {
	
	private String id;
    private String name;
    private String address;
    
    public Employee(String id, String name, String address) { // constructor
           this.id = id;
           this.name = name;
           this.address = address;
    }
 
    @Override
    public String toString() {
           return "Employee [id=" + id + ", name=" + name + ", address=" + address + ",]   ";
    }
    
}
 

class LinkedListEmptyException extends RuntimeException{
       public LinkedListEmptyException(){
         super();
       }
      
     public LinkedListEmptyException(String message){
         super(message);
       }  
}
 

class Node<T> {
    public T data; // data in Node.
    public Node<T> next; // points to next Node in list.
 
    
    public Node(T data){
           this.data = data;
    }
 
    
    public void displayNode() {
           System.out.print( data + " ");
    }
}
 

class LinkedList<T> {
    private Node<T> first; 
    public LinkedList(){
           first = null;
    }
 
    
    public void addInput(T data) {
           Node<T> newNode = new Node<T>(data);  
           newNode.next = first;   
           first = newNode;  
    }
 
   
   
           
    
    public void displayLinkedList() {
           System.out.print("Displaying LinkedList [first--->last]: ");
           Node<T> tempDisplay = first;
           while (tempDisplay != null)
           { 
                  tempDisplay.displayNode();
                  tempDisplay = tempDisplay.next; 
           }
           System.out.println();
           
    }


	

	
 
}
 
  
