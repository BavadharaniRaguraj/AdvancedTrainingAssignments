package employee;

import java.util.ListIterator;
import java.util.Iterator;

public class SinglyLinkedListGenericExample {

	 public static void main(String[] args) {
         LinkedList<Employee> linkedList = new LinkedList<Employee>();
         
         linkedList.addInput(new Employee("11", "sam", "trichy"));
         linkedList.addInput(new Employee("21", "amy", "erode"));
         linkedList.addInput(new Employee("59", "katy", "kerala"));
         linkedList.addInput(new Employee("14", "sai", "ooty"));
         linkedList.addInput(new Employee("39", "pat", "coorg"));
         
         linkedList.displayLinkedList();
         
	 }
}
