import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class App {

	 
	public static void main(String[] args) throws FileNotFoundException{
				
		File file=new File("SampleText.txt");
		
		BufferedReader br=new BufferedReader(new FileReader(file));
		
	
	String st;
	
	Integer sum=0;
	
	try {
		while((st=br.readLine())!=null)
		{
			sum = Integer.parseInt(st);
			System.out.println(st);
			
			
			int i,y=1;  
			  Integer x=sum;    
			  for(i=1;i<=x;i++){    
			      y=y*i;    
			  }    
			  System.out.println("Factorial of "+x+" is: "+y);    
			
		
		}
	
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}
	
}





/**/
