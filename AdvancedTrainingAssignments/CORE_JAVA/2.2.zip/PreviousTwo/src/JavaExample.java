import java.util.Scanner;

public class JavaExample {

	 public static void main(String[] args) { 
		 Scanner s=new Scanner(System.in);
		 
		
		 System.out.println("Enter first number :");
		 int num1 = s.nextInt();
		 System.out.println("Enter second number :");
		 int num2 = s.nextInt(); 
		 System.out.println("Next 13 Numbers are :"); 
		 for (int i = 1; i <= 15; ++i) 
		 {
			 System.out.print(num1+" ");
		 /* On each iteration, we are assigning second number * to the first number and assigning the sum of last two * numbers to the second number */ 
		 int sumOfPrevTwo = num1 + num2; 
		 num1 = num2; 
		 num2 = sumOfPrevTwo;
		 }
		
	 }


	
}
