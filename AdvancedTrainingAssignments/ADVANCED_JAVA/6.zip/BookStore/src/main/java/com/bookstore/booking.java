package com.bookstore;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/booking")
public class booking extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		
		String bname=request.getParameter("txtbname");
		
		int quantity=Integer.parseInt(request.getParameter("txtquan"));
		
		String uname=request.getParameter("txtuname");
		String email=request.getParameter("txtemail");
		int mobile=Integer.parseInt(request.getParameter("txtnum"));
		
		
		//int res=price*nop;
		
		
		try {
			
			//2) Create Con Connection
			Connection con=ConnectionPro.getConnection();
			
			//3)  Call Procedure
			CallableStatement stmt=con.prepareCall("{call book1(?,?,?,?)}");
			stmt.registerOutParameter(1,Types.INTEGER);
		    stmt.setString(2,bname);
		    stmt.registerOutParameter(3,Types.VARCHAR);
		    stmt.registerOutParameter(4,Types.VARCHAR);
		    
		    stmt.execute();
		 
			
		
		response.setContentType("text/HTML");
		PrintWriter out=response.getWriter();
		
		out.println("<h4>NAME :"+uname+"</h4>");
		out.println("<h4>EMAIL :"+email+"</h4>");
		
		out.println("<h4>MOBILE :"+mobile+"</h4>");
		
		out.println("<h4>BOOK NAME : "+bname+"</h4>");
		out.println("<h4>BOOK ID : "+stmt.getInt(1)+"</h4>");
		out.println("<h4>AUTHOR : "+stmt.getString(3)+"</h4>");
		
		out.println("<h4>PRICE : "+stmt.getDouble(4)+"</h4>");
		
		double a=stmt.getDouble(4);
		double tot=a*quantity;
		
		out.println("<h4>TOTAL PRICE : "+tot+"</h4>");
		
		
		
		out.println("<h2>Successfully Booked!! Have a Happy Reading!!<h2>");
		con.close();
		}
		catch(Exception e) {
				e.printStackTrace();
		}

		
	}

}

