package com.bookstore;

import java.sql.*;

public class UserDatabase {
	
	Connection con ;

    public UserDatabase(Connection con) {
        this.con = con;
    }
    
    
    public boolean saveUser(User user){
        boolean set = false;
        try{
            
            String query = "insert into users(first_name,address,email,mob_no,password) values(?,?,?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, user.getName());
           pt.setString(2, user.getAddress());
           pt.setString(3, user.getEmail());
           pt.setString(4, user.getMobile());
           pt.setString(5, user.getPassword());
           
           pt.executeUpdate();
           set = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return set;
    }

}
